package com.myocean.domain.ug.enums;

public enum PersonaType {
    FAMILY, FRIEND, STRANGER
}