package com.myocean.domain.friendchat.enums;

public enum InvitationStatus {
    PENDING, ACCEPTED, REJECTED, CANCELLED
}