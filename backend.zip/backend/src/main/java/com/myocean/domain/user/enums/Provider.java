package com.myocean.domain.user.enums;

public enum Provider {
    GOOGLE, KAKAO
}