package com.myocean.domain.diarychat.enums;

public enum AiStatus {
    UNSET, PLANNED, GENERATING, READY, FAILED
}