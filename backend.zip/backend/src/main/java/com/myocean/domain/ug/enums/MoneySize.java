package com.myocean.domain.ug.enums;

public enum MoneySize {
    고액, 소액
}