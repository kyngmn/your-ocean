package com.myocean.domain.user.enums;

public enum ActorKind {
    USER, PERSONA
}