package com.myocean.domain.gamemanagement.enums;

public enum SessionType {
    DIARY, GAME, CHAT
}