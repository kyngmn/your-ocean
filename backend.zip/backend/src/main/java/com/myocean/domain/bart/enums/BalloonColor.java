package com.myocean.domain.bart.enums;

public enum BalloonColor {
    RED, BLUE, GREEN
}