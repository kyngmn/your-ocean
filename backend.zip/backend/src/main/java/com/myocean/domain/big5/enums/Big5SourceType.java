package com.myocean.domain.big5.enums;

public enum Big5SourceType {
    SURVEY,
    GAME,
    DIARY
}