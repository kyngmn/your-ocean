package com.myocean.domain.gamemanagement.enums;

public enum GameType {
    BART, GNG, UG
}