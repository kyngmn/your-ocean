package com.myocean.domain.gng.enums;

public enum GngStimulus {
    GO, NOGO
}