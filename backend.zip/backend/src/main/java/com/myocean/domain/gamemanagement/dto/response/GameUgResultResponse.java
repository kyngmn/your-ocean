package com.myocean.domain.gamemanagement.dto.response;

public class GameUgResultResponse {
}
