package com.myocean.domain.user.enums;

public enum AiStatus {
    UNSET, GENERATING, GENERATED
}