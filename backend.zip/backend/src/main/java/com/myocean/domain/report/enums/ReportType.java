package com.myocean.domain.report.enums;

public enum ReportType {
    SELF, FINAL
}